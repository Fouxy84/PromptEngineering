import { Card, CardContent } from "@/components/ui/card"
import { Search, PenTool, BarChart3, Megaphone, Globe, Smartphone } from "lucide-react"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Navigation */}
      <nav className="border-b border-gray-800 bg-gray-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-xl font-bold text-blue-400">DigitalEdge</h1>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <a href="/" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors">
                  Home
                </a>
                <a
                  href="/about"
                  className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                >
                  About
                </a>
                <a
                  href="#contact"
                  className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                >
                  Contact
                </a>
              </div>
            </div>
            <div className="md:hidden">
              <button className="text-gray-300 hover:text-white">
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Our Services
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
              Comprehensive digital marketing solutions designed to elevate your brand and drive measurable results
            </p>
          </div>
        </div>

        {/* Background decoration */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl"></div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-blue-600/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Search className="h-8 w-8 text-blue-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">SEO Optimization</h3>
                <p className="text-gray-400 leading-relaxed">
                  Boost your search rankings with our comprehensive SEO strategies. We optimize your website to drive
                  organic traffic and increase visibility.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-purple-600/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <PenTool className="h-8 w-8 text-purple-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">Content Marketing</h3>
                <p className="text-gray-400 leading-relaxed">
                  Engage your audience with compelling content that tells your brand story and drives conversions across
                  all digital channels.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-green-600/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <BarChart3 className="h-8 w-8 text-green-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">Analytics & Insights</h3>
                <p className="text-gray-400 leading-relaxed">
                  Make data-driven decisions with our comprehensive analytics reporting and actionable insights to
                  optimize your marketing performance.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-orange-600/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Megaphone className="h-8 w-8 text-orange-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">Paid Advertising</h3>
                <p className="text-gray-400 leading-relaxed">
                  Maximize your ROI with targeted PPC campaigns across Google, Facebook, and other platforms. We
                  optimize every dollar spent.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-cyan-600/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Globe className="h-8 w-8 text-cyan-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">Social Media Management</h3>
                <p className="text-gray-400 leading-relaxed">
                  Build and engage your community across all social platforms with strategic content and community
                  management that drives results.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-pink-600/20 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <Smartphone className="h-8 w-8 text-pink-400" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">Mobile Marketing</h3>
                <p className="text-gray-400 leading-relaxed">
                  Reach your audience on-the-go with mobile-optimized campaigns, app marketing, and location-based
                  targeting strategies.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-gray-400">
            <p>&copy; 2024 DigitalEdge. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
